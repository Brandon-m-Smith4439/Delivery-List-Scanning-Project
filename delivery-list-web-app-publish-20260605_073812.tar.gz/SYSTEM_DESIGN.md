# Delivery List System Design

Yes, this can become a real delivery-list system as a website/web app. The static prototype proves the operator interface, but production needs a shared data store and a small backend so multiple users can scan at the same time.

## Core Pieces

- Web app: desktop and mobile scanning UI.
- Backend API: validates scans, records scan events, serves current delivery lists.
- Database: stores delivery lists, line items, scan events, users, stations, bay assignments, and audit history.
- Importer: loads new delivery lists from Excel/CSV/SharePoint.
- Sync jobs: optional Power Automate or scheduled workers for SharePoint snapshots, alerts, and reports.

## Database Options

### SharePoint Lists

Best low-friction Microsoft 365 path. Good for permissions and Power Automate, but not ideal for very high scan volume or complex queries.

Recommended when IT will allow Microsoft 365 storage faster than a new server.

### SQLite

Simple local database file hosted with the web app. Fast and cheap for one-site LAN usage, but needs careful backup and one server/computer to host it.

Recommended for a plant-local pilot.

### PostgreSQL

Professional shared database for long-term use. Strong concurrency, reporting, backups, and audit history.

Recommended for the polished permanent system.

### SQL Server

Very strong fit if the company already supports Microsoft SQL Server. Best enterprise Microsoft path, but depends on IT access.

Recommended if IT will provide a database but not a vendor app.

## Multi-User Scanning

Multiple users can scan at the same time if every scan is recorded as an atomic server-side transaction:

1. Scanner submits barcode, station, user, delivery list, and timestamp.
2. Server canonicalizes or rejects the scan.
3. Server locks/checks the matching line item.
4. Server increments scanned quantity only if remaining quantity exists.
5. Server writes a scan-event row for audit history.
6. Server broadcasts the update to other open screens.

The browser must not be the source of truth for production quantity updates. The backend/database must decide.

## Delivery List Selector

The selector should come from a `delivery_lists` table:

- ID
- delivery date
- source file name
- status: draft, active, archived
- stage/profile
- imported by
- imported at
- revision

Each operator station can default to a stage, but users can switch lists when allowed.

## Indian Trail Bay Sorting

The Indian Trail auto sorting system can be included as a module in the same app:

- Store bay rules in a `bay_rules` table.
- Calculate suggested bay during import and again during scan if needed.
- Allow supervisor override with reason.
- Print/export bay labels or bay lists.
- Show bay counts live on the Indian Trail screen.

Rules can use dimensions, product type, route, customer, rack/bay capacity, and manual overrides.

## Power Automate

The system can still use Power Automate, but it should not depend on Power Automate for the critical scan transaction.

Good uses:

- Notify teams when a list is published.
- Save daily reports to SharePoint.
- Email/export exceptions.
- Copy snapshots to SharePoint for visibility.

Avoid:

- Using flows as the only real-time scan processor.
- Depending on flows for high-speed barcode validation.

## Recommended Rollout

1. Keep Excel master as source of truth.
2. Web app reads published JSON snapshots and writes scan events to a queue.
3. Master or a small service processes the queue.
4. Move source of truth to a database once users trust the web UI.
5. Keep Excel export/reporting for people who still need workbook output.

This gives a safe bridge instead of trying to replace everything in one jump.
